<?php

namespace App\SupportedApps\Remmina;

class Remmina extends \App\SupportedApps
{
}
