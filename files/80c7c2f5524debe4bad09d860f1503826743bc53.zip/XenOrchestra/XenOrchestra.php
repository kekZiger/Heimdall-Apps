<?php

namespace App\SupportedApps\XenOrchestra;

class XenOrchestra extends \App\SupportedApps
{
}
