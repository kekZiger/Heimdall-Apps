<?php

namespace App\SupportedApps\WeightsBiases;

class WeightsBiases extends \App\SupportedApps
{
}
