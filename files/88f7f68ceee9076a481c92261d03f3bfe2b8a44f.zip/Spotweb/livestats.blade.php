<ul class="livestats">
    <li>
        <span class="title">Last update</span>
        <span><strong>{!! $last_update !!}</strong></span>
    </li>
</ul>
