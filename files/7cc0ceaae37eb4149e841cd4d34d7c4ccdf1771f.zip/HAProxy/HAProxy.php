<?php

namespace App\SupportedApps\HAProxy;

class HAProxy extends \App\SupportedApps
{
}
