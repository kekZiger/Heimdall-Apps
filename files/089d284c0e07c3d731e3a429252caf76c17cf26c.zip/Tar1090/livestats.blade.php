<ul class="livestats">
    <li>
        <span class="title">Aircraft<br />with Pos</span>
        <strong>{!! $aircraft_with_pos !!}</strong>
    </li>
    <li>
        <span class="title">Aircraft<br />w/o Pos</span>
        <strong>{!! $aircraft_without_pos !!}</strong>
    </li>
</ul>
