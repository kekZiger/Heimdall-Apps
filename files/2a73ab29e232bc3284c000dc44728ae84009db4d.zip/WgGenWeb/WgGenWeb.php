<?php

namespace App\SupportedApps\WgGenWeb;

class WgGenWeb extends \App\SupportedApps
{
}
