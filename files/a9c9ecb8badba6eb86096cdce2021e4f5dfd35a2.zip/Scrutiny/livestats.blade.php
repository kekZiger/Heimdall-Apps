<ul class="livestats">
	<li>
		<span class="title">Passed</span>
		<strong>{!! $passed ?? 0 !!}</strong>
	</li>

	<li>
		<span class="title">Failed</span>
		<strong>{!! $failed ?? 0 !!}</strong>
	</li>
</ul>
