<?php

namespace App\SupportedApps\FileBot;

class FileBot extends \App\SupportedApps
{
}
