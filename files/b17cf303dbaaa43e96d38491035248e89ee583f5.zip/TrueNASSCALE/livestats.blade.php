<ul class="livestats">
    <li>
        <span class="title">Uptime</span>
        <strong>{!! $uptime !!}</strong>
    </li>
    <li>
        <span class="title">Alerts</span>
        <strong>{!! $alert_tot !!}  / <span style="background-color: #d64d55; padding: 3px; color: white; font-size: 12px; border-radius: 3px; opacity: 1;">{!! $alert_crit !!}</span></strong>
    </li>
</ul>
