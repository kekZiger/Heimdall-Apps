<ul class="livestats">
    <li>
        <span class="title">Mode</span>
        <strong>{!! $outbound_mode !!}</strong>
    </li>
    <li>
        <span class="title">{!! $sel_name !!}</span>
        <strong>{!! $sel_value !!}</strong>
    </li>
</ul>
