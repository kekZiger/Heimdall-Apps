<?php

namespace App\SupportedApps\Webmin;

class Webmin extends \App\SupportedApps
{
}
