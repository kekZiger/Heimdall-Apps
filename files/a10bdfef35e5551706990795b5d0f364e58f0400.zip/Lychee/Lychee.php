<?php

namespace App\SupportedApps\Lychee;

class Lychee extends \App\SupportedApps
{
}
