<?php

namespace App\SupportedApps\Poste;

class Poste extends \App\SupportedApps
{
}
