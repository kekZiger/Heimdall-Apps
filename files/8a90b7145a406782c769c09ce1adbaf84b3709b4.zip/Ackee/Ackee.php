<?php

namespace App\SupportedApps\Ackee;

class Ackee extends \App\SupportedApps
{
}
